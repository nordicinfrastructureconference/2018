﻿#Script to Block NTLM traffic from all sources and adding domain controller/file server to whitelist.
#Used for demo purposes. For production implementation guidance: https://blogs.technet.microsoft.com/askds/2009/10/08/ntlm-blocking-and-you-application-analysis-and-auditing-methodologies-in-windows-7/ 

function Invoke-Round1Mitigations{
    [CmdletBinding()]Param()

Write-Host -ForegroundColor Green `
"Adding RestrictSendingNTLMTraffic and whitelisting Domain Controller and File Server"
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0" -Name RestrictSendingNTLMTraffic -Value 2 -PropertyType DWORD
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0" -Name ClientAllowedNTLMServers -Value MSRL-Srv-ADFile -PropertyType MultiString

#Activate Attack Surface Reduction
Write-Host -ForegroundColor Green `
"Enabling following Attack Surface Reduction rules for Windows 10 1709: `n
Block executable content from email client and webmail`nBlock Office applications from creating child processes	`nBlock Office applications from creating executable content	`nBlock Office applications from injecting code into other processes	`nBlock JavaScript or VBScript from launching downloaded executable content	`nBlock execution of potentially obfuscated scripts  `n
Block Win32 API calls from Office macro"

Set-MpPreference -AttackSurfaceReductionRules_Ids `
BE9BA2D9-53EA-4CDC-84E5-9B1EEEE46550, `
D4F940AB-401B-4EFC-AADC-AD5F3C50688A, `
3B576869-A4EC-4529-8536-B80A7769E899, `
75668C1F-73B5-4CF0-BB93-3ECF5CB7CC84, `
D3E037E1-3EB8-44C8-A917-57927947596D, `
5BEB7EFE-FD9A-4556-801D-275E5FFC04CC, `
92E97FA1-2EDF-4476-BDD6-9DD0B4DDDC7B  `
-AttackSurfaceReductionRules_Actions AuditMode, AuditMode, AuditMode, AuditMode, AuditMode, AuditMode, AuditMode
#-AttackSurfaceReductionRules_Actions Enabled, Enabled, Enabled, Enabled, Enabled, Enabled, Enabled


## Test all settings are applied: 
#(Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0" | Select-Object -ExpandProperty RestrictSendingNTLMTraffic) -eq 2
#(Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0" | Select-Object -ExpandProperty ClientAllowedNTLMServers) -eq "MSRL-Srv-ADFile"

Write-Host -ForegroundColor Green `
"Enabling DDE Auto mitigation, disabling feature"
New-ItemProperty -Path "HKCU\Software\Microsoft\Office\16.0\Word\Options" -Name DontUpdateLinks -Value 1 -PropertyType DWORD
New-ItemProperty -Path "HKCU\Software\Microsoft\Office\15.0\Word\Options" -Name DontUpdateLinks -Value 1 -PropertyType DWORD
New-ItemProperty -Path "HKCU\Software\Microsoft\Office\16.0\Word\Options\Wordmail" -Name DontUpdateLinks -Value 1 -PropertyType DWORD
New-ItemProperty -Path "HKCU\Software\Microsoft\Office\15.0\Word\Options\Wordmail" -Name DontUpdateLinks -Value 1 -PropertyType DWORD
New-ItemProperty -Path "HKCU\Software\Microsoft\Office\16.0\OneNote\Options" -Name DisableEmbeddedFiles -Value 1 -PropertyType DWORD
New-ItemProperty -Path "HKCU\Software\Microsoft\Office\15.0\OneNote\Options" -Name DisableEmbeddedFiles -Value 1 -PropertyType DWORD
New-ItemProperty -Path "HKCU\Software\Microsoft\Office\16.0\Excel\Options" -Name DontUpdateLinks -Value 1 -PropertyType DWORD
New-ItemProperty -Path "HKCU\Software\Microsoft\Office\15.0\Excel\Options" -Name DontUpdateLinks -Value 1 -PropertyType DWORD
New-ItemProperty -Path "HKCU\Software\Microsoft\Office\16.0\Excel\Options" -Name DDEAllowed -Value 0 -PropertyType DWORD
New-ItemProperty -Path "HKCU\Software\Microsoft\Office\15.0\Excel\Options" -Name DDEAllowed -Value 0 -PropertyType DWORD
New-ItemProperty -Path "HKCU\Software\Microsoft\Office\16.0\Excel\Options" -Name DDECleaned -Value 1 -PropertyType DWORD
New-ItemProperty -Path "HKCU\Software\Microsoft\Office\15.0\Excel\Options" -Name DDECleaned -Value 1 -PropertyType DWORD
New-ItemProperty -Path "HKCU\Software\Microsoft\Office\16.0\Excel\Options" -Name Options -Value 279 -PropertyType DWORD

}