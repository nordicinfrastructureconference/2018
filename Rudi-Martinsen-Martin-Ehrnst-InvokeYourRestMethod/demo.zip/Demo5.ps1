########## Last Demo ############
# Run text analytics on tickets #
#################################
#region TextAnalytics function
    function Run-TextAnalytics {
 
    <#
     .SYNOPSIS
     Run phrase and sentiment analytics on supplied text.
     
     .DESCRIPTION
     Script recieves a text string input and run it through Microsoft translator, converting the text to English.
     The translated text is the fed to MSFT Text analytics API to run a sentiment and key phrase analisys.
 
     The concept is to try and determinate if the author of the text is happy or not, and what the text is about.
     IE: Run any open support tickets through to try and prioritize each ticket. or use the key phrases to automatickly route the ticket to the correct department
 
     .EXAMPLE
     Run-TextAnalytics.ps1 -ID 1234 -Text "My computer crashes all the time and it is your fault. I think it's the processor"
 
     Name                           Value                                                                                                                                                          
     ----                           -----                                                                                                                                                          
     Translation                    My computer crashes all the time and it is your fault. I think it's the processor                                                                              
     Sentiment Score                3,57 %                                                                                                                                                         
     Key phrases                    time, computer crashes, fault, processor
 
     .EXAMPLE
     Run-TextAnalytics.ps1 -ID 1234 -Text "Yes, that worked. Do you want to marry me?"
 
     Name                           Value                                                                                                                                                          
     ----                           -----                                                                                                                                                          
     Translation                    Yes, that worked. Do you want to marry me?                                                                                                                     
     Sentiment Score                91,88 %                                                                                                                                                        
     Key phrases             
 
     
     .NOTES
     Created by Martin Ehrnst
     www.adatum.no
 
     Please add your Translation and text analytics account keys
     
     
     .CHANGELOG
     12.01.17: v0.5 Beta (Initial release)
     18.01.17: v0.9 Beta
     Implemented error handling
 
     .TODO
     Add support for multiple jobs with one output. Possibly move to workflow to support parallel processing
    #>
 
 
    param (
        [Parameter(Mandatory = $True, Position = 1, valueFromPipeLine = $true)]
        [string]$text,
        [Parameter(Mandatory = $True, Position = 2, valueFromPipeLine = $true)]
        [INT]$ID
    )
 
    # decode incoming text
    $Encoding = [System.Text.Encoding]::GetEncoding('ISO-8859-1')
    $Utf8 = [System.Text.Encoding]::UTf8.GetBytes($text)
    $decodedMessage = $Encoding.GetString($utf8)
 
    #region Configuration
    $TransaccountKey = "<your key here>"
    $AnalyticsAccountKey = "<your key here>"
    $supportedLanguage = @("no", "da", "en", "sv", "fi")

    #endregion
 
    #region CreateToken
    #We create a translation token used as a header
    try {
        $tokenServiceURL = "https://api.cognitive.microsoft.com/sts/v1.0/issueToken"
        $query = "?Subscription-Key=$TransaccountKey"
        $TokenUri = $tokenServiceUrl + $query
        $token = Invoke-RestMethod -Uri $TokenUri -Method Post
 
        $Auth = "Bearer " + $token #setting the token used
    }
    catch {
        Write-Output "failed to create token"
        $_.Exception
    }
    #endregion
 
    $TextAnalyticsHeader = @{
        'Ocp-Apim-Subscription-Key' = $AnalyticsAccountKey
        'Content-Type'              = 'application/json; charset=utf-8'
    } #the header with your app key
 
    #region DetectLanguage
 
    try {
 
        $LangDetection = [ordered]@{
            "documents" = 
            @(
                @{
                    "id"   = $id;
                    "text" = $decodedMessage
                }
            )
        } | ConvertTo-Json
 
        $lang = invoke-restmethod -Method Post -Uri 'https://westus.api.cognitive.microsoft.com/text/analytics/v2.0/languages' -Body $LangDetection -Headers $TextAnalyticsHeader
        $detectedLanguage = $lang.documents.'detectedLanguages'.iso6391Name
        $language = $detectedLanguage
    }
     
    catch {
      write-error $error[0]
    }
 
    #endregion
     

    #region RunTranslation

    if ($supportedLanguage -notcontains $detectedLanguage) {
        Write-Verbose -Message "detected language $detectedLanguage not supported. Translating to English to perform analytics"
        
        $TextToTranslate = $decodedMessage
        [string]$ToLanguage = "en"
        try {
            $RunTrans = Invoke-RestMethod -Method Get -Headers  @{'Authorization' = $Auth} -Uri ('http://api.microsofttranslator.com/v2/Http.svc/Translate?text={0}&to={1}' -f `
                ($TextToTranslate, $ToLanguage | % { [Web.HttpUtility]::UrlEncode($_) } ))
        } #translating text
        catch {
            Write-Output "Failed to run translation. See exception"
            $_.Exception.Message
        }
 
        $translatedText = $runTrans.string.'#text'#The translated text

        #replace characters that are unsupported
        $translatedText = $translatedText -replace "[æå]", "a"
        $translatedText = $translatedText -replace "[øö]", "o"
        $translatedText = $translatedText -replace "[£$]", ""

        $decodedMessage = $translatedText
        
        # set languange to english, and use that in analytics
        $language = $ToLanguage

        #endregion
  
    }

        #region RunTextAnalytics
 
        #the body which contains language of the text, job id and the text it self
        $TextAnalyticsBody = [ordered]@{
            "documents" = 
            @(
                @{
                    "language" = $language;
                    "id"       = $id;
                    "text"     = $decodedMessage 
                }
            )
        } | ConvertTo-Json
 
        try {
            $RunSentiment = Invoke-RestMethod -Method post -Headers $TextAnalyticsHeader -uri 'https://westus.api.cognitive.microsoft.com/text/analytics/v2.0/sentiment' -Body $TextAnalyticsBody
            $sentimentScore = $RunSentiment.documents.score
            #$sentimentScore = $sentimentScore.ToString("P") #Converting value to percentage
        }
        catch {
            if ($($RunSentiment.errors)) {
                Write-Output "Failed to run sentiment"
                $_.Exception.Message
            }
        }
        try {
            $runPhrases = Invoke-RestMethod -Method post -Headers $TextAnalyticsHeader -uri 'https://westus.api.cognitive.microsoft.com/text/analytics/v2.0/keyPhrases' -Body $TextAnalyticsBody
            $keyPhrases = $runPhrases.documents.keyPhrases -join ', ' #seperate each phrase with a comma
        }
        catch {
            if ($($runPhrases.errors)) {
                Write-Output "Failed to run phrase"
                $_.Exception.Message
            }
        }
        #endregion
 
        $AnalysisResult = @{
            'Sentiment Score' = $sentimentScore;
            'Key phrases'     = $keyPhrases;
            'Text'            = $text;
            'Language'        = $language;
        }
        $AnalysisResult
    }
#endregion


#region modules
    Import-Module '.\modules\SwapiPS\SwapiPS.psm1'
    Import-Module '.\modules\SupportBeePS\SupportBeePS.psm1'
#endregion


# set supportbee token
$sbtoken = "<your token here>"
#region article
# Article
# http://www.bbc.com/news/world-us-canada-41958553

$text = "President Donald Trump has again traded barbs with North Korea, shortly before offering to mediate in a heated regional dispute.
He took to Twitter to complain he would never call North Korean leader Kim Jong-un 'short and fat', after its foreign ministry called him 'old'."
#endregion


# create ticket and pretend Biggs is writing about trump.
#region new ticket
    # get the name
    $person = (Get-SWAPIPeople -Query "Biggs").name


    $ticket = New-SBTicket -SupportBeeCompany nicdemo -Requester $person -RequesterEmail "biggs@s-tar-wars.io" -Subject "Trump & Kim" -Message $text -AuthToken $SBtoken
    $ticket
#endregion

# Get the tickets content and run analisys - this could be done during ticket creation as well.
#region get ticket data
    $analyticsResult = $null
    $ticketContent = (Get-SBTicket -TicketId ($ticket.ticket.id) -AuthToken $sbtoken).content.html

    $analyticsResult = Run-TextAnalytics -text $ticketContent -ID (Get-Random -Maximum 100)
    $analyticsResult
#endregion

# Add label to ticket based on analytics results
#region Labels
    # Add label based on key phrases
    if (($analyticsResult.'Key phrases').Split(' ,') -contains "Trump") {
       Add-SBLabel -TicketId $($ticket.ticket.id) -Label "POLITICS" -AuthToken $sbtoken
    }

    # Add a severity label based on the sentiment score
    if (($analyticsResult.'Sentiment Score') -lt "0,16") {
        Add-SBLabel -TicketId $($ticket.ticket.id) -Label "CRITICAL" -AuthToken $sbtoken
    }

    Get-SBTicket -TicketId ($ticket.ticket.id) -AuthToken $sbtoken

#endregion

