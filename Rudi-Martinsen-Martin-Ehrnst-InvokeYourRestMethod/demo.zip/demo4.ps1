####################
# Demo4 -- Modules #
####################

#region Create modules to help users with the hassle of creating header and body objects etc
    code .\modules\SwapiPS\SwapiPS.psm1
    code .\modules\SupportBeePS\SupportBeePS.psm1
    code .\modules\SupportBeePS\SupportBeePS.psd1
#end region

#region Swapi Module
    Import-Module .\modules\SwapiPS
    Get-Command -Module SwapiPS
    Get-SwapiPeople -query "Rey"
    Get-SwapiFilms | Sort-Object Release_date | Select-Object @{l="Title";e={"Episode " + $_.episode_id + " - " + $_.title}},Release_date
#end region

#region SupportBee Module
    Import-Module .\modules\SupportBeePS
    Get-Command -Module SupportBeePS

    $luke = Get-SWAPIPeople -Query "luke"
    $luke
    $response = New-SBTicket -SupportBeeCompany nicdemo -Requester $luke.name -RequesterEmail ($luke.name.split(" ")[0] + "@starwars.com")`
     -Subject "Lightsaber" -Message "I've lost my lightsaber. I've looked all over the place but cannot find it..."
    $response

    $token = "<your token here>"

    Get-SBTicket -SupportBeeCompany nicdemo -AuthToken $token | Sort-Object created_at -desc | Select-Object -First 1
    
    New-SBComment -Ticket $response.ticket -AuthToken $token `
    -Comment "Hi Luke, I've found it and will bring it to you shortly. Love, $($(Get-SwapiPeople -query "Rey").name)" 
    
#end region