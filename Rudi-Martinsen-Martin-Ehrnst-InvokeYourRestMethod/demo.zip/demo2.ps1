###################################
# Demo2 -- digging (a bit) deeper #
###################################

#region intro
    https://swapi.co/documentation
    $baseUrl = "https://swapi.co/api/"
#end region

#region search
    (Invoke-RestMethod -Method Get -Uri ($baseUrl + "people/?search=skywalker")).results
#end region

#region get object by id, often faster than search
    Invoke-RestMethod -Method Get -Uri ($baseUrl + "people/2")    
    $luke = Invoke-RestMethod -Method Get -Uri ($baseUrl + "people/1")
    $luke
    $luke.homeworld #Notice the url format. Wonder how we can use that...    
#end region

#region Make use of the linked objects
    $lukesHomeWorld = Invoke-RestMethod -Method Get -Uri $luke.homeworld
    $lukesHomeWorld
#end region

#region Make even more use of linked objects
    $newLukeObject = [pscustomobject]@{
        Name = $luke.name
        Height = $luke.height
        BirthYear = $luke.birth_year
        Gender = $luke.gender
        HomePlanet = $lukesHomeWorld.name
        Species = (Invoke-RestMethod -Method Get -Uri $($luke.species)).name
        Language = (Invoke-RestMethod -Method Get -Uri $($luke.species)).language
    }

    $luke

    $newLukeObject
#end region
 

