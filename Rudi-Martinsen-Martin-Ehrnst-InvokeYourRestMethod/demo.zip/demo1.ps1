##################
# Demo1 -- intro #
##################

#region Checkout swapi.co
    http://swapi.co/
#end region

#region Invoke-Restmethod
    Get-Help Invoke-RestMethod
#endregion

#region Invoke-Restmethod example
    Invoke-Restmethod -Method Get -Uri http://swapi.co/api/people
    $response = Invoke-RestMethod -Method Get -Uri http://swapi.co/api/people
    $response.results
    $response.results[0]
#end region

#region What about Invoke-Webrequest
    (Get-Help Invoke-WebRequest).synopsis
    Invoke-WebRequest -Method Get -Uri http://swapi.co/api/people
    $response = Invoke-WebRequest -Method Get -Uri http://swapi.co/api/people
    $response.Content
    $response.Content | ConvertFrom-Json
#end region

#region But there is some nice things with Invoke-Webrequest as well...
    Invoke-RestMethod http://www.vg.no
    Invoke-WebRequest http://www.vg.no
    $response = Invoke-WebRequest http://www.vg.no
    $response.StatusCode
    $response.Links[4]
#end region