####################
# Demo3 -- Posting #
####################


#region Intro to Support Bee
    https://supportbee.com
    https://nicdemo.supportbee.com
    https://developers.supportbee.com/api
#end region

#region get tickets
    $headers = @{
        "Content-Type" = 'application/json';
        "Accept" = 'application/json';
    }
    $token = "<your token here>"
    $supportbeeUrl = "https://nicdemo.supportbee.com/tickets?auth_token=$token"
    $response = Invoke-RestMethod -Method Get -Uri $supportbeeUrl -Headers $headers
    $response
    $response.tickets
    $response.tickets | Select-Object subject,created_at,unanswered,@{l="Requester";e={$_.requester.name}}
#end region



#region create ticket
    $subject = "This is a test"
    $swapiPerson = Invoke-RestMethod -Method Get -Uri "http://swapi.co/api/people/1"
    $name = $swapiPerson.name
    $email = $name.split(" ")[0] + "@example.com"
$data = @"
{
    "ticket": {
        "subject": "$subject",
        "requester_name": "$name",
        "requester_email": "$email"
        "content": {
            "text": "We are creating a new ticket with Invoke-Restmethod!"
        }
    }
}
"@
    $data
    $response = Invoke-RestMethod -Method Post -Uri $supportbeeUrl -Body $data -Headers $headers
    $response.ticket
#end region

#region check tickets
    $response = Invoke-RestMethod -Method Get -Uri $supportbeeUrl -Headers $headers
    $response.tickets | select subject,created_at,unanswered,@{l="Requester";e={$_.requester.name}}
#end region 
