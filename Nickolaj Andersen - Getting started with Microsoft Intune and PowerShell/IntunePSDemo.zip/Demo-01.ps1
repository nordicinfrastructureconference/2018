# Install PSIntuneAuth module
Install-Module -Name PSIntuneAuth

# Import PSIntuneAuth module
Import-Module -Name PSIntuneAuth

# Set admin consent
Set-MSIntuneAdminConsent -TenantName "configmgrse.onmicrosoft.com" -UserPrincipalName "nickolaj@corp.scconfigmgr.com"