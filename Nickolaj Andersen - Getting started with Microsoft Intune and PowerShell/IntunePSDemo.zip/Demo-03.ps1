# Import PSIntuneAuth module
Import-Module -Name PSIntuneAuth

# Acquire authentication token
$AuthToken = Get-MSIntuneAuthToken -TenantName emsmgmt.onmicrosoft.com -PromptBehavior Always

# Construct array list for all devices
$AppsList = New-Object -TypeName "System.Collections.ArrayList"

# Get managed devices from Graph API
$MobileAppsResource = "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps"
$RESTResponse = Invoke-RestMethod -Method Get -Headers $AuthToken -Uri $MobileAppsResource

if ($RESTResponse.value.Count -ge 2) {
    $AppsList.AddRange($RESTResponse.value) | Out-Null
}
else {
    $AppsList.Add($RESTResponse.value) | Out-Null
}

# Handle paging
$AppsNextLink = $RESTResponse."@odata.nextLink"
while ($AppsNextLink -ne $null) {
    $RESTResponse = Invoke-RestMethod -Uri $RESTResponse."@odata.nextLink" -Method Get -Headers $AuthToken
    $AppsNextLink = $RESTResponse."@odata.nextLink"
    if ($AppsNextLink -eq $null) {
        Write-Output -InputObject "NextLink is now empty or null"
    }
    else {
        $AppsList.Add($RESTResponse.value) | Out-Null
    }
}

# List mobile apps
$AppsList