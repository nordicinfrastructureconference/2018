# Import PSIntuneAuth module
Import-Module -Name PSIntuneAuth

# Acquire authentication token
$AuthToken = Get-MSIntuneAuthToken -TenantName emsmgmt.onmicrosoft.com -PromptBehavior Always

# Get mobile apps from Graph API
$MobileAppsResource = "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps"
$RESTResponse = Invoke-RestMethod -Method Get -Headers $AuthToken -Uri $MobileAppsResource

# Process response from Graph API
if (-not[string]::IsNullOrEmpty($RESTResponse.Value)) {
    $RESTResponse.value.displayName
}

# Filtering with startswith
$MobileAppsResourceFiltered = "https://graph.microsoft.com/beta/deviceAppManagement/mobileApps?`$filter=startswith(displayName, 'Word')"
$RESTResponse = Invoke-RestMethod -Method Get -Headers $AuthToken -Uri $MobileAppsResourceFiltered

# Process response from Graph API
if (-not[string]::IsNullOrEmpty($RESTResponse.Value)) {
    $RESTResponse.value.displayName
}